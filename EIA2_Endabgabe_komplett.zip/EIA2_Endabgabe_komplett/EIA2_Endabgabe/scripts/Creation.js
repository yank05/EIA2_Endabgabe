var Firework;
(function (Firework) {
    class Creation {
        name;
        constructor(_name) {
            this.name = _name;
        }
    }
    Firework.Creation = Creation;
})(Firework || (Firework = {}));
//# sourceMappingURL=Creation.js.map